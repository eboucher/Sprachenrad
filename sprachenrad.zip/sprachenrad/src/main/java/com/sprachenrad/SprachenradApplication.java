package com.sprachenrad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprachenradApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprachenradApplication.class, args);
	}

}
